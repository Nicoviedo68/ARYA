<?php

declare(strict_types=1);

namespace Arya\Models;

use Arya\Core\Database;

/**
 * Conversaciones y mensajes omnicanal (producción).
 */
final class Omnichannel
{
    private static bool $bootstrapped = false;

    public static function bootstrap(): void
    {
        if (self::$bootstrapped) {
            return;
        }
        self::$bootstrapped = true;

        $pdo = Database::connection();
        if (!$pdo) {
            return;
        }

        try {
            $ready = false;
            try {
                $pdo->query('SELECT 1 FROM omni_conversations LIMIT 1');
                $pdo->query('SELECT 1 FROM omni_messages LIMIT 1');
                $ready = true;
            } catch (\Throwable) {
                $ready = false;
            }

            if (!$ready) {
                $pdo->exec(
                    'CREATE TABLE IF NOT EXISTS omni_conversations (
                        id                 BIGSERIAL PRIMARY KEY,
                        channel            VARCHAR(40)  NOT NULL,
                        external_contact   VARCHAR(120) NOT NULL,
                        contact_name       VARCHAR(150),
                        phone              VARCHAR(80),
                        page_id            VARCHAR(120),
                        phone_number_id    VARCHAR(120),
                        preview            TEXT,
                        status             VARCHAR(30)  NOT NULL DEFAULT \'open\',
                        unread_count       INT          NOT NULL DEFAULT 0,
                        last_message_at    TIMESTAMPTZ,
                        created_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
                        updated_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW()
                    )'
                );
                $pdo->exec(
                    'CREATE UNIQUE INDEX IF NOT EXISTS uq_omni_conv_channel_contact
                     ON omni_conversations (channel, external_contact)'
                );
                $pdo->exec('CREATE INDEX IF NOT EXISTS idx_omni_conv_last ON omni_conversations (last_message_at DESC NULLS LAST)');

                $pdo->exec(
                    'CREATE TABLE IF NOT EXISTS omni_messages (
                        id                 BIGSERIAL PRIMARY KEY,
                        conversation_id    BIGINT NOT NULL REFERENCES omni_conversations(id) ON DELETE CASCADE,
                        direction          VARCHAR(20) NOT NULL DEFAULT \'inbound\',
                        sender             VARCHAR(20) NOT NULL DEFAULT \'client\',
                        body               TEXT NOT NULL,
                        message_type       VARCHAR(40) NOT NULL DEFAULT \'text\',
                        external_id        VARCHAR(200),
                        media_url          TEXT,
                        raw                JSONB,
                        created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    )'
                );
                $pdo->exec(
                    'CREATE UNIQUE INDEX IF NOT EXISTS uq_omni_msg_external
                     ON omni_messages (external_id) WHERE external_id IS NOT NULL'
                );
                $pdo->exec('CREATE INDEX IF NOT EXISTS idx_omni_msg_conv ON omni_messages (conversation_id, created_at)');

                try {
                    $pdo->exec('ALTER TABLE meta_webhook_inbox ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ');
                    $pdo->exec('ALTER TABLE omni_messages ADD COLUMN IF NOT EXISTS media_url TEXT');
                    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_meta_inbox_unprocessed ON meta_webhook_inbox (id) WHERE processed_at IS NULL');
                } catch (\Throwable) {
                    // ignore
                }
            }

            // Columnas DM/comentario (idempotente, también en tablas ya existentes)
            try {
                $pdo->exec("ALTER TABLE omni_conversations ADD COLUMN IF NOT EXISTS thread_kind VARCHAR(20) NOT NULL DEFAULT 'message'");
                $pdo->exec('ALTER TABLE omni_conversations ADD COLUMN IF NOT EXISTS comment_id VARCHAR(120)');
                $pdo->exec('ALTER TABLE omni_conversations ADD COLUMN IF NOT EXISTS post_id VARCHAR(120)');
                $pdo->exec('ALTER TABLE omni_conversations ADD COLUMN IF NOT EXISTS post_media_url TEXT');
                $pdo->exec('ALTER TABLE omni_conversations ADD COLUMN IF NOT EXISTS post_permalink TEXT');
                $pdo->exec('ALTER TABLE omni_conversations ADD COLUMN IF NOT EXISTS post_caption TEXT');
                $pdo->exec('ALTER TABLE omni_messages ADD COLUMN IF NOT EXISTS media_url TEXT');
                $pdo->exec('ALTER TABLE meta_webhook_inbox ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ');
            } catch (\Throwable) {
                // ignore
            }
        } catch (\Throwable) {
            // sin DB
        }
    }

    /** Sync ligero: solo si hay pendientes. */
    public static function syncPendingIfAny(): int
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return 0;
        }
        try {
            $hasPending = (bool) $pdo->query(
                'SELECT EXISTS(SELECT 1 FROM meta_webhook_inbox WHERE processed_at IS NULL)'
            )->fetchColumn();
            if (!$hasPending) {
                return 0;
            }
        } catch (\Throwable) {
            return 0;
        }

        $result = self::syncFromMetaInbox();
        return (int) ($result['synced'] ?? 0);
    }

    /**
     * @return list<array{id:string,name:string,icon:string,color:string,unread:int,online:bool}>
     */
    public static function channels(): array
    {
        self::bootstrap();
        $unread = self::unreadByChannel();

        $defs = [
            ['id' => 'whatsapp',  'name' => 'WhatsApp',  'icon' => 'whatsapp',  'color' => '#25D366'],
            ['id' => 'messenger', 'name' => 'Messenger', 'icon' => 'facebook',  'color' => '#1877F2'],
            ['id' => 'instagram', 'name' => 'Instagram', 'icon' => 'instagram', 'color' => '#E4405F'],
            ['id' => 'web',       'name' => 'Web Chat',  'icon' => 'globe',     'color' => '#00F0FF'],
        ];

        $out = [];
        foreach ($defs as $d) {
            $out[] = [
                'id'     => $d['id'],
                'name'   => $d['name'],
                'icon'   => $d['icon'],
                'color'  => $d['color'],
                'unread' => (int) ($unread[$d['id']] ?? 0),
                'online' => true,
            ];
        }
        return $out;
    }

    /**
     * @return array<string,int>
     */
    private static function unreadByChannel(): array
    {
        $pdo = Database::connection();
        if (!$pdo) {
            return [];
        }
        try {
            $stmt = $pdo->query(
                'SELECT channel, COALESCE(SUM(unread_count),0)::int AS unread
                 FROM omni_conversations
                 GROUP BY channel'
            );
            $map = [];
            foreach ($stmt->fetchAll() as $row) {
                $map[(string) $row['channel']] = (int) $row['unread'];
            }
            return $map;
        } catch (\Throwable) {
            return [];
        }
    }

    /**
     * @return list<array<string,mixed>>
     */
    public static function conversations(?string $channel = null): array
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return [];
        }

        try {
            if ($channel && $channel !== 'all') {
                $stmt = $pdo->prepare(
                    'SELECT id, channel, external_contact, contact_name, phone, preview, status,
                            unread_count, last_message_at, page_id, phone_number_id,
                            thread_kind, comment_id, post_id, post_media_url, post_permalink, post_caption
                     FROM omni_conversations
                     WHERE channel = :channel
                     ORDER BY last_message_at DESC NULLS LAST, id DESC
                     LIMIT 80'
                );
                $stmt->execute(['channel' => $channel]);
            } else {
                $stmt = $pdo->query(
                    'SELECT id, channel, external_contact, contact_name, phone, preview, status,
                            unread_count, last_message_at, page_id, phone_number_id,
                            thread_kind, comment_id, post_id, post_media_url, post_permalink, post_caption
                     FROM omni_conversations
                     ORDER BY last_message_at DESC NULLS LAST, id DESC
                     LIMIT 80'
                );
            }

            $rows = $stmt ? $stmt->fetchAll() : [];
            return array_map([self::class, 'mapConversation'], $rows);
        } catch (\Throwable) {
            return [];
        }
    }

    public static function findConversation(int|string $id): ?array
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return null;
        }
        try {
            $stmt = $pdo->prepare('SELECT * FROM omni_conversations WHERE id = :id LIMIT 1');
            $stmt->execute(['id' => $id]);
            $row = $stmt->fetch();
            return $row ? self::mapConversation($row) : null;
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * @return list<array{id:int|string,from:string,text:string,time:string,type:string,media_url:?string}>
     */
    public static function messages(int|string $conversationId, bool $markRead = true): array
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return [];
        }

        try {
            $stmt = $pdo->prepare(
                'SELECT id, sender, body, message_type, media_url, created_at
                 FROM omni_messages
                 WHERE conversation_id = :id
                 ORDER BY created_at ASC, id ASC'
            );
            $stmt->execute(['id' => $conversationId]);
            $out = [];
            foreach ($stmt->fetchAll() as $row) {
                $out[] = [
                    'id'        => $row['id'],
                    'from'      => (string) $row['sender'],
                    'text'      => (string) $row['body'],
                    'type'      => (string) ($row['message_type'] ?? 'text'),
                    'media_url' => $row['media_url'] !== null ? (string) $row['media_url'] : null,
                    'time'      => self::formatTime((string) $row['created_at']),
                ];
            }

            if ($markRead) {
                $pdo->prepare('UPDATE omni_conversations SET unread_count = 0, updated_at = NOW() WHERE id = :id')
                    ->execute(['id' => $conversationId]);
            }

            return $out;
        } catch (\Throwable) {
            return [];
        }
    }

    /**
     * Guarda mensaje saliente del agente.
     *
     * @return array{ok:bool,message:string,id?:int}
     */
    public static function storeOutbound(
        int $conversationId,
        string $body,
        string $type = 'text',
        ?string $mediaUrl = null,
        ?string $externalId = null
    ): array {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return ['ok' => false, 'message' => 'Sin DB'];
        }

        try {
            $stmt = $pdo->prepare(
                'INSERT INTO omni_messages
                    (conversation_id, direction, sender, body, message_type, media_url, external_id, created_at)
                 VALUES
                    (:cid, \'outbound\', \'agent\', :body, :type, :media_url, :external_id, NOW())
                 RETURNING id'
            );
            $stmt->execute([
                'cid'         => $conversationId,
                'body'        => $body,
                'type'        => $type,
                'media_url'   => $mediaUrl,
                'external_id' => $externalId,
            ]);
            $id = (int) $stmt->fetchColumn();

            $preview = $body !== '' ? $body : ('[' . $type . ']');
            $pdo->prepare(
                'UPDATE omni_conversations SET
                    preview = :preview,
                    last_message_at = NOW(),
                    status = \'open\',
                    updated_at = NOW()
                 WHERE id = :id'
            )->execute([
                'preview' => mb_substr($preview, 0, 280),
                'id'      => $conversationId,
            ]);

            return ['ok' => true, 'message' => 'Mensaje guardado', 'id' => $id];
        } catch (\Throwable $e) {
            return ['ok' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Sincroniza eventos pendientes de meta_webhook_inbox → omni_*.
     *
     * @return array{ok:bool, synced:int, message:string}
     */
    public static function syncFromMetaInbox(): array
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return ['ok' => false, 'synced' => 0, 'message' => 'Sin DB'];
        }

        $synced = 0;
        try {
            $stmt = $pdo->query(
                "SELECT id, object_type, page_id, canal, event_type, payload, created_at
                 FROM meta_webhook_inbox
                 WHERE processed_at IS NULL
                 ORDER BY id ASC
                 LIMIT 200"
            );
            $rows = $stmt ? $stmt->fetchAll() : [];

            foreach ($rows as $row) {
                $n = self::ingestInboxRow($pdo, $row);
                $synced += $n;

                // Comentarios IG/FB: si falló el ingest pero el payload es usable, reintentar luego.
                // (messaging/otros se marcan siempre para no atascar la cola con receipts).
                $eventType = strtolower((string) ($row['event_type'] ?? ''));
                if (
                    $n === 0
                    && in_array($eventType, ['comments', 'live_comments', 'feed'], true)
                    && self::inboxCommentShouldRetry($row)
                ) {
                    continue;
                }

                $pdo->prepare('UPDATE meta_webhook_inbox SET processed_at = NOW() WHERE id = :id')
                    ->execute(['id' => $row['id']]);
            }
        } catch (\Throwable $e) {
            return ['ok' => false, 'synced' => $synced, 'message' => $e->getMessage()];
        }

        return ['ok' => true, 'synced' => $synced, 'message' => "Sincronizados {$synced} mensajes"];
    }

    /**
     * ¿El inbox de comentario tiene datos mínimos y aún no existe en omni?
     *
     * @param array<string,mixed> $row
     */
    private static function inboxCommentShouldRetry(array $row): bool
    {
        $payload = $row['payload'] ?? null;
        if (is_string($payload)) {
            $payload = json_decode($payload, true);
        }
        if (!is_array($payload)) {
            return false;
        }
        $change = $payload['changes'][0] ?? null;
        if (!is_array($change)) {
            return false;
        }
        $value = $change['value'] ?? null;
        if (is_string($value)) {
            $value = json_decode($value, true);
        }
        if (!is_array($value)) {
            return false;
        }

        $field = strtolower((string) ($change['field'] ?? ($row['event_type'] ?? '')));
        if ($field === 'feed' && strtolower((string) ($value['item'] ?? '')) !== 'comment') {
            return false;
        }
        if (strtolower((string) ($value['verb'] ?? 'add')) === 'remove') {
            return false;
        }

        $commentId = trim((string) ($value['id'] ?? $value['comment_id'] ?? ''));
        if ($commentId === '') {
            return false;
        }

        try {
            $pdo = Database::connection();
            if (!$pdo) {
                return true;
            }
            $stmt = $pdo->prepare(
                "SELECT 1 FROM omni_conversations
                 WHERE comment_id = :cid OR external_contact = :ext
                 LIMIT 1"
            );
            $stmt->execute(['cid' => $commentId, 'ext' => 'cmt:' . $commentId]);
            if ($stmt->fetchColumn()) {
                return false; // ya está en omni → no reintentar
            }
        } catch (\Throwable) {
            return true;
        }

        return true;
    }

    /**
     * @param array<string,mixed> $row
     */
    private static function ingestInboxRow(\PDO $pdo, array $row): int
    {
        $payload = $row['payload'] ?? null;
        if (is_string($payload)) {
            $payload = json_decode($payload, true);
        }
        if (!is_array($payload)) {
            return 0;
        }

        $canal = strtolower((string) ($row['canal'] ?? ''));
        $pageId = (string) ($row['page_id'] ?? ($payload['id'] ?? ''));
        $createdAt = (string) ($row['created_at'] ?? date('c'));
        $count = 0;

        // Messenger / Instagram DM: entry.messaging[]
        $messaging = $payload['messaging'] ?? null;
        if (is_array($messaging)) {
            $dmCanal = $canal !== '' ? $canal : 'messenger';
            if ($dmCanal === 'page') {
                $dmCanal = 'messenger';
            }
            foreach ($messaging as $msg) {
                if (!is_array($msg)) {
                    continue;
                }
                $count += self::ingestMessengerItem($pdo, $msg, $pageId, $dmCanal, $createdAt) ? 1 : 0;
            }
        }

        // changes[]: WhatsApp messages | IG comments | FB feed comments
        $changes = $payload['changes'] ?? null;
        if (is_array($changes)) {
            foreach ($changes as $change) {
                if (!is_array($change)) {
                    continue;
                }
                $field = strtolower((string) ($change['field'] ?? ($row['event_type'] ?? '')));
                $value = $change['value'] ?? null;
                if (is_string($value)) {
                    $decoded = json_decode($value, true);
                    $value = is_array($decoded) ? $decoded : null;
                }
                if (!is_array($value)) {
                    continue;
                }

                if ($field === 'messages' || ($canal === 'whatsapp' && isset($value['messages']))) {
                    $count += self::ingestWhatsAppValue($pdo, $value, $pageId, 'whatsapp', $createdAt);
                    continue;
                }

                // Instagram comments (object=instagram, field=comments|live_comments)
                if (
                    $field === 'comments'
                    || $field === 'live_comments'
                    || (
                        $canal === 'instagram'
                        && (
                            isset($value['id'])
                            || isset($value['comment_id'])
                        )
                        && (isset($value['text']) || isset($value['message']))
                    )
                ) {
                    $count += self::ingestInstagramComment($pdo, $value, $pageId, $createdAt) ? 1 : 0;
                    continue;
                }

                // Facebook Page feed comment
                if ($field === 'feed' && strtolower((string) ($value['item'] ?? '')) === 'comment') {
                    $count += self::ingestFacebookComment($pdo, $value, $pageId, $createdAt) ? 1 : 0;
                }
            }
        }

        return $count;
    }

    /**
     * @param array<string,mixed> $value
     */
    private static function ingestWhatsAppValue(
        \PDO $pdo,
        array $value,
        string $pageId,
        string $canal,
        string $fallbackAt
    ): int {
        $messages = $value['messages'] ?? null;
        if (!is_array($messages) || $messages === []) {
            return 0; // statuses, etc.
        }

        $contacts = $value['contacts'] ?? [];
        $contactName = '';
        $waId = '';
        if (is_array($contacts) && isset($contacts[0]) && is_array($contacts[0])) {
            $waId = (string) ($contacts[0]['wa_id'] ?? '');
            $contactName = (string) ($contacts[0]['profile']['name'] ?? '');
        }

        $meta = is_array($value['metadata'] ?? null) ? $value['metadata'] : [];
        $phoneNumberId = (string) ($meta['phone_number_id'] ?? '');
        $displayPhone = (string) ($meta['display_phone_number'] ?? '');

        $count = 0;
        foreach ($messages as $msg) {
            if (!is_array($msg)) {
                continue;
            }
            $from = (string) ($msg['from'] ?? $waId);
            if ($from === '') {
                continue;
            }
            $externalId = (string) ($msg['id'] ?? '');
            $type = (string) ($msg['type'] ?? 'text');
            $body = self::extractWhatsAppBody($msg, $type);
            if ($body === '') {
                $body = '[' . $type . ']';
            }

            $ts = (string) ($msg['timestamp'] ?? '');
            $at = $fallbackAt;
            if ($ts !== '' && ctype_digit($ts)) {
                $at = gmdate('Y-m-d H:i:sP', (int) $ts);
            }

            $name = $contactName !== '' ? $contactName : ('+' . $from);
            $convId = self::upsertConversation($pdo, [
                'channel'          => 'whatsapp',
                'external_contact' => $from,
                'contact_name'     => $name,
                'phone'            => '+' . ltrim($from, '+'),
                'page_id'          => $pageId !== '' ? $pageId : null,
                'phone_number_id'  => $phoneNumberId !== '' ? $phoneNumberId : null,
                'preview'          => $body,
                'at'               => $at,
                'thread_kind'      => 'message',
                'comment_id'       => null,
            ]);

            if (self::insertMessage($pdo, $convId, [
                'direction'   => 'inbound',
                'sender'      => 'client',
                'body'        => $body,
                'message_type'=> $type,
                'external_id' => $externalId !== '' ? $externalId : null,
                'raw'         => $msg,
                'at'          => $at,
            ])) {
                $count++;
            }
        }

        // silence unused
        unset($displayPhone);

        return $count;
    }

    /**
     * @param array<string,mixed> $msg
     */
    private static function extractWhatsAppBody(array $msg, string $type): string
    {
        if ($type === 'text' && isset($msg['text']['body'])) {
            return trim((string) $msg['text']['body']);
        }
        if ($type === 'button' && isset($msg['button']['text'])) {
            return trim((string) $msg['button']['text']);
        }
        if ($type === 'interactive') {
            $inter = $msg['interactive'] ?? [];
            if (isset($inter['button_reply']['title'])) {
                return trim((string) $inter['button_reply']['title']);
            }
            if (isset($inter['list_reply']['title'])) {
                return trim((string) $inter['list_reply']['title']);
            }
        }
        if ($type === 'image' && isset($msg['image']['caption'])) {
            return trim((string) $msg['image']['caption']) ?: '[imagen]';
        }
        if ($type === 'audio') {
            return '[audio]';
        }
        if ($type === 'document') {
            return '[documento]';
        }
        if ($type === 'sticker') {
            return '[sticker]';
        }
        return '';
    }

    /**
     * @param array<string,mixed> $msg
     */
    private static function ingestMessengerItem(
        \PDO $pdo,
        array $msg,
        string $pageId,
        string $canal,
        string $fallbackAt
    ): bool {
        $senderId = (string) (($msg['sender']['id'] ?? '') ?: '');
        if ($senderId === '' || $senderId === $pageId) {
            return false; // echo / page
        }
        $text = trim((string) ($msg['message']['text'] ?? ''));
        if ($text === '') {
            $text = '[mensaje]';
        }
        $externalId = (string) ($msg['message']['mid'] ?? '');
        $ts = (string) ($msg['timestamp'] ?? '');
        $at = $fallbackAt;
        if ($ts !== '' && ctype_digit($ts)) {
            // Messenger timestamps are ms
            $n = (int) $ts;
            if ($n > 20000000000) {
                $n = (int) floor($n / 1000);
            }
            $at = gmdate('Y-m-d H:i:sP', $n);
        }

        $canal = $canal === 'instagram' ? 'instagram' : 'messenger';

        $name = self::resolveContactDisplayName($pdo, $canal, $senderId, $pageId);

        $convId = self::upsertConversation($pdo, [
            'channel'          => $canal,
            'external_contact' => $senderId,
            'contact_name'     => $name,
            'phone'            => $senderId,
            'page_id'          => $pageId !== '' ? $pageId : null,
            'phone_number_id'  => null,
            'preview'          => $text,
            'at'               => $at,
            'thread_kind'      => 'message',
            'comment_id'       => null,
        ]);

        if (!self::isPlaceholderName($name)) {
            self::propagateContactName($pdo, $canal, $senderId, $name);
        }

        return self::insertMessage($pdo, $convId, [
            'direction'    => 'inbound',
            'sender'       => 'client',
            'body'         => $text,
            'message_type' => 'text',
            'external_id'  => $externalId !== '' ? $externalId : null,
            'raw'          => $msg,
            'at'           => $at,
        ]);
    }

    /** ¿Nombre genérico tipo "Usuario 112434"? */
    private static function isPlaceholderName(string $name): bool
    {
        $name = trim($name);
        if ($name === '') {
            return true;
        }
        return (bool) preg_match('/^Usuario\s+\d+$/iu', $name);
    }

    /**
     * Busca nombre real: otros hilos (comentario/DM) → Graph API → fallback.
     */
    private static function resolveContactDisplayName(\PDO $pdo, string $channel, string $psid, string $pageId = ''): string
    {
        $known = self::findKnownContactName($pdo, $channel, $psid);
        if ($known !== null && !self::isPlaceholderName($known)) {
            return $known;
        }

        $fromGraph = null;
        if ($channel === 'instagram') {
            $fromGraph = \Arya\Services\MetaCloud::fetchInstagramProfileName($psid);
        } else {
            $fromGraph = \Arya\Services\MetaCloud::fetchMessengerProfileName($psid, $pageId !== '' ? $pageId : null);
        }
        if (is_string($fromGraph) && trim($fromGraph) !== '' && !self::isPlaceholderName($fromGraph)) {
            return trim($fromGraph);
        }

        return $known ?? ('Usuario ' . substr($psid, -6));
    }

    private static function findKnownContactName(\PDO $pdo, string $channel, string $psid): ?string
    {
        try {
            $stmt = $pdo->prepare(
                "SELECT contact_name FROM omni_conversations
                 WHERE channel = :channel
                   AND (external_contact = :psid OR phone = :psid)
                   AND contact_name IS NOT NULL
                   AND TRIM(contact_name) <> ''
                   AND contact_name NOT LIKE 'Usuario %'
                 ORDER BY
                   CASE WHEN thread_kind = 'comment' THEN 0 ELSE 1 END,
                   updated_at DESC NULLS LAST
                 LIMIT 1"
            );
            $stmt->execute(['channel' => $channel, 'psid' => $psid]);
            $name = $stmt->fetchColumn();
            return is_string($name) && trim($name) !== '' ? trim($name) : null;
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * Propaga un nombre real a todos los hilos del mismo PSID (DM + comentarios).
     */
    private static function propagateContactName(\PDO $pdo, string $channel, string $psid, string $name): void
    {
        $name = trim($name);
        $psid = trim($psid);
        if ($name === '' || $psid === '' || self::isPlaceholderName($name)) {
            return;
        }
        try {
            $stmt = $pdo->prepare(
                "UPDATE omni_conversations SET
                    contact_name = :name,
                    updated_at = NOW()
                 WHERE channel = :channel
                   AND (
                        external_contact = :psid
                     OR phone = :psid
                   )
                   AND (
                        contact_name IS NULL
                     OR TRIM(contact_name) = ''
                     OR contact_name LIKE 'Usuario %'
                   )"
            );
            $stmt->execute([
                'name'    => $name,
                'channel' => $channel,
                'psid'    => $psid,
            ]);

            // También actualiza cliente CRM si existe
            try {
                $pdo->prepare(
                    "UPDATE arya_clients SET
                        name = CASE
                            WHEN name IS NULL OR TRIM(name) = '' OR name LIKE 'Usuario %' THEN :name
                            ELSE name
                        END,
                        updated_at = NOW()
                     WHERE channel = :channel
                       AND (
                            external_contact = :psid
                         OR phone = :psid
                         OR regexp_replace(COALESCE(phone, ''), '\\D', '', 'g') = :psid
                       )"
                )->execute(['name' => $name, 'channel' => $channel, 'psid' => $psid]);
            } catch (\Throwable) {
                // tabla clientes opcional
            }
        } catch (\Throwable) {
            // ignore
        }
    }

    /**
     * Backfill: aplica nombres de comentarios a DMs del mismo PSID.
     * Solo corre si hay DMs con nombre placeholder que ya tienen comentario con nombre real.
     */
    public static function syncMessengerDisplayNames(): int
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return 0;
        }
        $n = 0;
        try {
            $needs = (bool) $pdo->query(
                "SELECT EXISTS (
                    SELECT 1
                    FROM omni_conversations dm
                    INNER JOIN omni_conversations cmt
                      ON cmt.channel = dm.channel
                     AND cmt.thread_kind = 'comment'
                     AND cmt.phone IS NOT NULL
                     AND TRIM(cmt.phone) <> ''
                     AND (cmt.phone = dm.external_contact OR cmt.phone = dm.phone)
                     AND cmt.contact_name IS NOT NULL
                     AND cmt.contact_name NOT LIKE 'Usuario %'
                    WHERE dm.channel IN ('messenger', 'instagram')
                      AND (dm.thread_kind = 'message' OR dm.thread_kind IS NULL)
                      AND (dm.contact_name IS NULL OR dm.contact_name LIKE 'Usuario %')
                 )"
            )->fetchColumn();
            if (!$needs) {
                return 0;
            }

            $rows = $pdo->query(
                "SELECT DISTINCT channel, phone, contact_name
                 FROM omni_conversations
                 WHERE thread_kind = 'comment'
                   AND phone IS NOT NULL AND TRIM(phone) <> ''
                   AND contact_name IS NOT NULL
                   AND contact_name NOT LIKE 'Usuario %'
                   AND channel IN ('messenger', 'instagram')"
            )->fetchAll();
            foreach ($rows as $row) {
                self::propagateContactName(
                    $pdo,
                    (string) $row['channel'],
                    (string) $row['phone'],
                    (string) $row['contact_name']
                );
                $n++;
            }
        } catch (\Throwable) {
            return $n;
        }
        return $n;
    }

    /**
     * @param array<string,mixed> $value
     */
    private static function ingestInstagramComment(\PDO $pdo, array $value, string $pageId, string $fallbackAt): bool
    {
        $commentId = trim((string) ($value['id'] ?? $value['comment_id'] ?? ''));
        if ($commentId === '') {
            return false;
        }
        // Borrados / edits sin texto útil
        if (strtolower((string) ($value['verb'] ?? 'add')) === 'remove') {
            return true; // consumir evento sin crear hilo
        }

        $text = trim((string) ($value['text'] ?? $value['message'] ?? ''));
        if ($text === '') {
            $text = '[comentario]';
        }
        $from = is_array($value['from'] ?? null) ? $value['from'] : [];
        $fromId = (string) ($from['id'] ?? '');
        $fromName = trim((string) ($from['username'] ?? $from['name'] ?? ''));
        if ($fromName !== '' && !str_starts_with($fromName, '@') && !str_contains($fromName, ' ')) {
            // username IG → @user
            $fromName = '@' . ltrim($fromName, '@');
        }
        if ($fromName === '') {
            $fromName = $fromId !== '' ? ('@' . substr($fromId, -6)) : ('Comentario ' . substr($commentId, -6));
        }

        // Primero crear hilo (Graph media no debe bloquear el comentario)
        $mediaId = (string) (
            (is_array($value['media'] ?? null) ? ($value['media']['id'] ?? '') : '')
            ?: ($value['media_id'] ?? $value['parent_id'] ?? '')
        );
        $convId = self::upsertConversation($pdo, [
            'channel'          => 'instagram',
            'external_contact' => 'cmt:' . $commentId,
            'contact_name'     => $fromName,
            'phone'            => $fromId !== '' ? $fromId : $commentId,
            'page_id'          => $pageId !== '' ? $pageId : null,
            'phone_number_id'  => null,
            'preview'          => $text,
            'at'               => $fallbackAt,
            'thread_kind'      => 'comment',
            'comment_id'       => $commentId,
            'post_id'          => $mediaId !== '' ? $mediaId : null,
            'post_media_url'   => null,
            'post_permalink'   => null,
            'post_caption'     => null,
        ]);

        if ($fromId !== '' && !self::isPlaceholderName($fromName)) {
            self::propagateContactName($pdo, 'instagram', $fromId, $fromName);
        }

        $ok = self::insertMessage($pdo, $convId, [
            'direction'    => 'inbound',
            'sender'       => 'client',
            'body'         => $text,
            'message_type' => 'comment',
            'external_id'  => $commentId,
            'raw'          => $value,
            'at'           => $fallbackAt,
        ]);

        // Enrichment opcional (token IG / Graph); no tumba el ingest
        try {
            self::enrichCommentMediaIfNeeded($convId);
        } catch (\Throwable) {
            // ignore
        }

        // true si el hilo existe (aunque el mensaje sea duplicado del mismo comment_id)
        return $ok || $convId > 0;
    }

    /**
     * @param array<string,mixed> $value
     */
    private static function ingestFacebookComment(\PDO $pdo, array $value, string $pageId, string $fallbackAt): bool
    {
        if (strtolower((string) ($value['verb'] ?? 'add')) === 'remove') {
            return true;
        }
        $commentId = (string) ($value['comment_id'] ?? $value['id'] ?? '');
        if ($commentId === '') {
            return false;
        }
        $text = trim((string) ($value['message'] ?? ''));
        if ($text === '') {
            $text = '[comentario]';
        }
        $from = is_array($value['from'] ?? null) ? $value['from'] : [];
        $fromId = (string) ($from['id'] ?? '');
        $fromName = trim((string) ($from['name'] ?? ''));
        if ($fromName === '') {
            $fromName = $fromId !== '' ? ('Usuario ' . substr($fromId, -6)) : ('Comentario ' . substr($commentId, -6));
        }

        $postId = trim((string) ($value['post_id'] ?? $value['parent_id'] ?? ''));
        $convId = self::upsertConversation($pdo, [
            'channel'          => 'messenger',
            'external_contact' => 'cmt:' . $commentId,
            'contact_name'     => $fromName,
            'phone'            => $fromId !== '' ? $fromId : $commentId,
            'page_id'          => $pageId !== '' ? $pageId : null,
            'phone_number_id'  => null,
            'preview'          => $text,
            'at'               => $fallbackAt,
            'thread_kind'      => 'comment',
            'comment_id'       => $commentId,
            'post_id'          => $postId !== '' ? $postId : null,
            'post_media_url'   => null,
            'post_permalink'   => null,
            'post_caption'     => null,
        ]);

        // Mismo PSID que el DM de Messenger → unificar nombre en todos los hilos
        if ($fromId !== '' && !self::isPlaceholderName($fromName)) {
            self::propagateContactName($pdo, 'messenger', $fromId, $fromName);
        }

        $ok = self::insertMessage($pdo, $convId, [
            'direction'    => 'inbound',
            'sender'       => 'client',
            'body'         => $text,
            'message_type' => 'comment',
            'external_id'  => $commentId,
            'raw'          => $value,
            'at'           => $fallbackAt,
        ]);

        try {
            self::enrichCommentMediaIfNeeded($convId);
        } catch (\Throwable) {
            // ignore
        }

        return $ok || $convId > 0;
    }

    /**
     * Si un comentario aún no tiene imagen del post, intenta enriquecerla vía Graph.
     */
    public static function enrichCommentMediaIfNeeded(int|string $conversationId): void
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return;
        }
        try {
            $stmt = $pdo->prepare(
                'SELECT id, channel, comment_id, post_id, post_media_url, thread_kind
                 FROM omni_conversations WHERE id = :id LIMIT 1'
            );
            $stmt->execute(['id' => $conversationId]);
            $row = $stmt->fetch();
            if (!$row || (string) ($row['thread_kind'] ?? '') !== 'comment') {
                return;
            }
            if (!empty($row['post_media_url'])) {
                return;
            }

            $channel = (string) $row['channel'];
            $value = [
                'comment_id' => (string) ($row['comment_id'] ?? ''),
                'post_id'    => (string) ($row['post_id'] ?? ''),
                'id'         => (string) ($row['comment_id'] ?? ''),
            ];
            // Intentar raw del primer mensaje inbound
            $rawStmt = $pdo->prepare(
                'SELECT raw FROM omni_messages
                 WHERE conversation_id = :id AND direction = \'inbound\'
                 ORDER BY id ASC LIMIT 1'
            );
            $rawStmt->execute(['id' => $conversationId]);
            $raw = $rawStmt->fetchColumn();
            if (is_string($raw) && $raw !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $value = array_merge($value, $decoded);
                }
            }

            $ctx = \Arya\Services\MetaCloud::resolveCommentPostContext($channel, $value);
            if (!$ctx['ok']) {
                return;
            }
            $upd = $pdo->prepare(
                'UPDATE omni_conversations SET
                    post_id = COALESCE(NULLIF(:post_id, \'\'), post_id),
                    post_media_url = COALESCE(NULLIF(:media, \'\'), post_media_url),
                    post_permalink = COALESCE(NULLIF(:permalink, \'\'), post_permalink),
                    post_caption = COALESCE(NULLIF(:caption, \'\'), post_caption),
                    updated_at = NOW()
                 WHERE id = :id'
            );
            $upd->execute([
                'id'        => $conversationId,
                'post_id'   => (string) ($ctx['post_id'] ?? ''),
                'media'     => (string) ($ctx['media_url'] ?? ''),
                'permalink' => (string) ($ctx['permalink'] ?? ''),
                'caption'   => (string) ($ctx['caption'] ?? ''),
            ]);
        } catch (\Throwable) {
            // ignore
        }
    }

    /** Fuerza guardar post_id/permalink mínimos desde raw aunque Graph falle. */
    public static function seedCommentPostRefs(int|string $conversationId): void
    {
        self::bootstrap();
        $pdo = Database::connection();
        if (!$pdo) {
            return;
        }
        try {
            $rawStmt = $pdo->prepare(
                'SELECT raw FROM omni_messages
                 WHERE conversation_id = :id AND direction = \'inbound\'
                 ORDER BY id ASC LIMIT 1'
            );
            $rawStmt->execute(['id' => $conversationId]);
            $raw = $rawStmt->fetchColumn();
            $value = is_string($raw) ? (json_decode($raw, true) ?: []) : [];
            if (!is_array($value)) {
                return;
            }
            $postId = trim((string) ($value['post_id'] ?? $value['parent_id'] ?? ''));
            if ($postId === '') {
                return;
            }
            $link = 'https://www.facebook.com/' . $postId;
            $pdo->prepare(
                'UPDATE omni_conversations SET
                    post_id = COALESCE(post_id, :post_id),
                    post_permalink = COALESCE(post_permalink, :link),
                    updated_at = NOW()
                 WHERE id = :id AND thread_kind = \'comment\''
            )->execute(['id' => $conversationId, 'post_id' => $postId, 'link' => $link]);
        } catch (\Throwable) {
            // ignore
        }
    }

    /**
     * @param array{channel:string,external_contact:string,contact_name:string,phone:?string,page_id:?string,phone_number_id:?string,preview:string,at:string,thread_kind?:string,comment_id?:?string,post_id?:?string,post_media_url?:?string,post_permalink?:?string,post_caption?:?string} $data
     */
    private static function upsertConversation(\PDO $pdo, array $data): int
    {
        $threadKind = (string) ($data['thread_kind'] ?? 'message');
        if ($threadKind !== 'comment') {
            $threadKind = 'message';
        }
        $commentId = $data['comment_id'] ?? null;
        if ($commentId !== null) {
            $commentId = trim((string) $commentId);
            if ($commentId === '') {
                $commentId = null;
            }
        }
        $postId = isset($data['post_id']) ? trim((string) $data['post_id']) : '';
        $postMedia = isset($data['post_media_url']) ? trim((string) $data['post_media_url']) : '';
        $postLink = isset($data['post_permalink']) ? trim((string) $data['post_permalink']) : '';
        $postCap = isset($data['post_caption']) ? trim((string) $data['post_caption']) : '';

        $stmt = $pdo->prepare(
            'INSERT INTO omni_conversations
                (channel, external_contact, contact_name, phone, page_id, phone_number_id, preview, status,
                 unread_count, last_message_at, updated_at, thread_kind, comment_id,
                 post_id, post_media_url, post_permalink, post_caption)
             VALUES
                (:channel, :external_contact, :contact_name, :phone, :page_id, :phone_number_id, :preview, \'open\',
                 1, CAST(:at AS TIMESTAMPTZ), NOW(), :thread_kind, :comment_id,
                 NULLIF(:post_id, \'\'), NULLIF(:post_media_url, \'\'), NULLIF(:post_permalink, \'\'), NULLIF(:post_caption, \'\'))
             ON CONFLICT (channel, external_contact) DO UPDATE SET
                contact_name = CASE
                    WHEN omni_conversations.contact_name IS NULL OR TRIM(omni_conversations.contact_name) = \'\'
                        THEN EXCLUDED.contact_name
                    WHEN omni_conversations.contact_name LIKE \'Usuario %\'
                         AND EXCLUDED.contact_name IS NOT NULL
                         AND EXCLUDED.contact_name NOT LIKE \'Usuario %\'
                        THEN EXCLUDED.contact_name
                    WHEN EXCLUDED.contact_name LIKE \'Usuario %\'
                        THEN omni_conversations.contact_name
                    ELSE COALESCE(NULLIF(TRIM(EXCLUDED.contact_name), \'\'), omni_conversations.contact_name)
                END,
                phone = COALESCE(EXCLUDED.phone, omni_conversations.phone),
                page_id = COALESCE(EXCLUDED.page_id, omni_conversations.page_id),
                phone_number_id = COALESCE(EXCLUDED.phone_number_id, omni_conversations.phone_number_id),
                preview = EXCLUDED.preview,
                status = \'open\',
                unread_count = omni_conversations.unread_count + 1,
                last_message_at = EXCLUDED.last_message_at,
                thread_kind = COALESCE(EXCLUDED.thread_kind, omni_conversations.thread_kind),
                comment_id = COALESCE(EXCLUDED.comment_id, omni_conversations.comment_id),
                post_id = COALESCE(EXCLUDED.post_id, omni_conversations.post_id),
                post_media_url = COALESCE(EXCLUDED.post_media_url, omni_conversations.post_media_url),
                post_permalink = COALESCE(EXCLUDED.post_permalink, omni_conversations.post_permalink),
                post_caption = COALESCE(EXCLUDED.post_caption, omni_conversations.post_caption),
                updated_at = NOW()
             RETURNING id'
        );
        $stmt->execute([
            'channel'          => $data['channel'],
            'external_contact' => $data['external_contact'],
            'contact_name'     => $data['contact_name'],
            'phone'            => $data['phone'],
            'page_id'          => $data['page_id'],
            'phone_number_id'  => $data['phone_number_id'],
            'preview'          => mb_substr($data['preview'], 0, 280),
            'at'               => $data['at'],
            'thread_kind'      => $threadKind,
            'comment_id'       => $commentId,
            'post_id'          => $postId,
            'post_media_url'   => $postMedia,
            'post_permalink'   => $postLink,
            'post_caption'     => mb_substr($postCap, 0, 500),
        ]);

        $convId = (int) $stmt->fetchColumn();

        // Alta/actualización automática en Gestión de clientes
        try {
            Client::upsertFromOmni([
                'channel'              => (string) $data['channel'],
                'external_contact'     => (string) $data['external_contact'],
                'contact_name'         => (string) ($data['contact_name'] ?? ''),
                'phone'                => $data['phone'] !== null ? (string) $data['phone'] : null,
                'omni_conversation_id' => $convId,
                'status'               => 'open',
                'at'                   => (string) $data['at'],
            ]);
        } catch (\Throwable) {
            // no bloquear inbox si falla el CRM
        }

        return $convId;
    }

    /**
     * @param array{direction:string,sender:string,body:string,message_type:string,external_id:?string,raw:array,at:string} $data
     */
    private static function insertMessage(\PDO $pdo, int $conversationId, array $data): bool
    {
        try {
            if (!empty($data['external_id'])) {
                $check = $pdo->prepare('SELECT 1 FROM omni_messages WHERE external_id = :eid LIMIT 1');
                $check->execute(['eid' => $data['external_id']]);
                if ($check->fetchColumn()) {
                    return false;
                }
            }

            $stmt = $pdo->prepare(
                'INSERT INTO omni_messages
                    (conversation_id, direction, sender, body, message_type, external_id, raw, created_at)
                 VALUES
                    (:conversation_id, :direction, :sender, :body, :message_type, :external_id, CAST(:raw AS JSONB), CAST(:at AS TIMESTAMPTZ))'
            );
            $stmt->execute([
                'conversation_id' => $conversationId,
                'direction'       => $data['direction'],
                'sender'          => $data['sender'],
                'body'            => $data['body'],
                'message_type'    => $data['message_type'],
                'external_id'     => $data['external_id'],
                'raw'             => json_encode($data['raw'], JSON_UNESCAPED_UNICODE) ?: '{}',
                'at'              => $data['at'],
            ]);

            return $stmt->rowCount() > 0;
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * @param array<string,mixed> $row
     * @return array<string,mixed>
     */
    private static function mapConversation(array $row): array
    {
        $kind = (string) ($row['thread_kind'] ?? 'message');
        if ($kind !== 'comment') {
            $kind = 'message';
        }

        return [
            'id'      => (int) $row['id'],
            'channel' => (string) $row['channel'],
            'client'  => (string) ($row['contact_name'] ?: $row['external_contact']),
            'phone'   => (string) ($row['phone'] ?: $row['external_contact']),
            'preview' => (string) ($row['preview'] ?? ''),
            'time'    => self::formatTime((string) ($row['last_message_at'] ?? $row['created_at'] ?? '')),
            'unread'  => (int) ($row['unread_count'] ?? 0),
            'status'  => (string) ($row['status'] ?? 'open'),
            'page_id' => (string) ($row['page_id'] ?? ''),
            'phone_number_id' => (string) ($row['phone_number_id'] ?? ''),
            'external_contact'=> (string) ($row['external_contact'] ?? ''),
            'thread_kind'     => $kind,
            'comment_id'      => (string) ($row['comment_id'] ?? ''),
            'post_id'         => (string) ($row['post_id'] ?? ''),
            'post_media_url'  => (string) ($row['post_media_url'] ?? ''),
            'post_permalink'  => (string) ($row['post_permalink'] ?? ''),
            'post_caption'    => (string) ($row['post_caption'] ?? ''),
        ];
    }

    private static function formatTime(string $ts): string
    {
        if ($ts === '') {
            return '';
        }
        try {
            $dt = new \DateTimeImmutable($ts);
            $dt = $dt->setTimezone(new \DateTimeZone('America/Bogota'));
            $today = new \DateTimeImmutable('today', new \DateTimeZone('America/Bogota'));
            if ($dt->format('Y-m-d') === $today->format('Y-m-d')) {
                return $dt->format('H:i');
            }
            return $dt->format('d/m H:i');
        } catch (\Throwable) {
            return $ts;
        }
    }
}

<?php

declare(strict_types=1);

namespace Arya\Controllers;

use Arya\Core\Controller;
use Arya\Models\Omnichannel;
use Arya\Services\MetaCloud;
use Arya\Services\OpenAiAssist;

final class OmnichannelController extends Controller
{
    public function index(): void
    {
        $this->requireMenuAccess('omnichannel');
        Omnichannel::bootstrap();
        // Sync ligero de pendientes (incluye comentarios feed recién llegados)
        Omnichannel::syncPendingIfAny();
        // Unifica nombres Messenger/IG: comentario → DM del mismo usuario
        Omnichannel::syncMessengerDisplayNames();

        $channel = (string) ($_GET['canal'] ?? 'all');
        $selectedId = (int) ($_GET['chat'] ?? ($_GET['comentario'] ?? 0));

        $channels = Omnichannel::channels();
        $conversations = Omnichannel::conversations($channel);

        $selected = null;
        if ($selectedId > 0) {
            $selected = Omnichannel::findConversation($selectedId);
        }
        if (!$selected && $conversations) {
            $selected = $conversations[0];
        }

        if ($selected && ($selected['thread_kind'] ?? '') === 'comment') {
            if (($selected['post_id'] ?? '') === '') {
                Omnichannel::seedCommentPostRefs((int) $selected['id']);
            }
            if (($selected['post_media_url'] ?? '') === '') {
                Omnichannel::enrichCommentMediaIfNeeded((int) $selected['id']);
            }
            $selected = Omnichannel::findConversation((int) $selected['id']) ?? $selected;
        }

        // Mensajes solo del chat activo (una query)
        $messages = $selected ? Omnichannel::messages((int) $selected['id']) : [];

        $this->view('omnichannel/index', [
            'title'          => 'Omnicanalidad',
            'active'         => 'omnichannel',
            'channels'       => $channels,
            'conversations'  => $conversations,
            'currentChannel' => $channel,
            'selected'       => $selected,
            'messages'       => $messages,
        ]);
    }

    public function show(string $id): void
    {
        // Deep-link → misma shell SPA (sin doble carga pesada)
        $_GET['chat'] = $id;
        $_GET['canal'] = 'all';
        $this->index();
    }

    public function apiConversations(): void
    {
        $this->requireMenuAccess('omnichannel');
        Omnichannel::bootstrap();
        Omnichannel::syncPendingIfAny();
        Omnichannel::syncMessengerDisplayNames();

        $channel = (string) ($_GET['canal'] ?? 'all');
        $this->json([
            'ok'            => true,
            'channel'       => $channel,
            'channels'      => Omnichannel::channels(),
            'conversations' => Omnichannel::conversations($channel),
        ]);
    }

    public function apiMessages(string $id): void
    {
        $this->requireMenuAccess('omnichannel');
        Omnichannel::bootstrap();

        $conv = Omnichannel::findConversation($id);
        if (!$conv) {
            $this->json(['ok' => false, 'message' => 'Conversación no encontrada'], 404);
        }

        $hadUnread = (int) ($conv['unread'] ?? 0) > 0;
        if (($conv['thread_kind'] ?? '') === 'comment') {
            if (($conv['post_id'] ?? '') === '') {
                Omnichannel::seedCommentPostRefs((int) $conv['id']);
            }
            if (($conv['post_media_url'] ?? '') === '') {
                Omnichannel::enrichCommentMediaIfNeeded((int) $conv['id']);
            }
            $conv = Omnichannel::findConversation($conv['id']) ?? $conv;
        }
        $messages = Omnichannel::messages((int) $conv['id']);
        $conv['unread'] = 0;

        $payload = [
            'ok'           => true,
            'conversation' => $conv,
            'messages'     => $messages,
        ];
        // Solo recalcular badges si había unread (ahorra 1 query)
        if ($hadUnread) {
            $payload['channels'] = Omnichannel::channels();
        }
        $this->json($payload);
    }

    public function send(): void
    {
        $this->validateCsrf();
        $this->requireMenuAccess('omnichannel');
        $ajax = $this->wantsJson();

        $conversationId = (int) ($_POST['conversation_id'] ?? 0);
        $text = trim((string) ($_POST['message'] ?? ''));
        $conv = Omnichannel::findConversation($conversationId);

        if (!$conv) {
            $this->failSend('Conversación no encontrada.', $conversationId, $ajax, 404);
        }

        $channel = strtolower((string) ($conv['channel'] ?? ''));
        if (!in_array($channel, ['whatsapp', 'messenger', 'instagram'], true)) {
            $this->failSend('Canal no soportado para envío.', $conversationId, $ajax);
        }

        $hasFile = isset($_FILES['media']) && (int) ($_FILES['media']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
        if ($text === '' && !$hasFile) {
            $this->failSend('Escribe un mensaje o adjunta un archivo.', $conversationId, $ajax);
        }

        if ($hasFile) {
            if ($channel !== 'whatsapp') {
                $this->failSend('Los adjuntos por ahora solo están en WhatsApp.', $conversationId, $ajax);
            }
            $this->sendMediaMessage($conv, $text, $ajax);
            return;
        }

        $sent = MetaCloud::sendForConversation($conv, $text);
        if (!$sent['ok']) {
            $this->failSend('No se pudo enviar: ' . $sent['message'], $conversationId, $ajax);
        }

        $msgType = ((string) ($conv['thread_kind'] ?? '')) === 'comment' ? 'comment' : 'text';
        $store = Omnichannel::storeOutbound(
            $conversationId,
            $text,
            $msgType,
            null,
            $sent['external_id'] ?? null
        );
        if (!$store['ok']) {
            $this->failSend('Enviado a Meta, pero no se guardó local: ' . $store['message'], $conversationId, $ajax);
        }

        if ($ajax) {
            $this->json([
                'ok'      => true,
                'message' => 'Mensaje enviado.',
                'msg'     => [
                    'id'        => $store['id'] ?? null,
                    'from'      => 'agent',
                    'text'      => $text,
                    'type'      => 'text',
                    'media_url' => null,
                    'time'      => date('H:i'),
                ],
                'conversation' => Omnichannel::findConversation($conversationId),
            ]);
        }

        flash('success', 'Mensaje enviado.');
        redirect('omnicanalidad?chat=' . $conversationId);
    }

    public function improve(): void
    {
        $this->validateCsrf();
        $this->requireMenuAccess('omnichannel');

        $draft = trim((string) ($_POST['message'] ?? ''));
        $conversationId = (int) ($_POST['conversation_id'] ?? 0);

        $context = '';
        if ($conversationId > 0) {
            $msgs = Omnichannel::messages($conversationId, false);
            foreach (array_slice($msgs, -6) as $m) {
                $who = ($m['from'] ?? '') === 'agent' ? 'Agente' : 'Cliente';
                $context .= $who . ': ' . ($m['text'] ?? '') . "\n";
            }
        }

        $this->json(OpenAiAssist::improveMessage($draft, $context));
    }

    /**
     * @param array<string,mixed> $conv
     */
    private function sendMediaMessage(array $conv, string $caption, bool $ajax): void
    {
        $conversationId = (int) $conv['id'];
        $file = $_FILES['media'] ?? null;
        if (!is_array($file) || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $this->failSend('Error al subir el archivo.', $conversationId, $ajax);
        }

        $tmp = (string) ($file['tmp_name'] ?? '');
        $size = (int) ($file['size'] ?? 0);
        $orig = (string) ($file['name'] ?? 'file');
        $mime = (string) ($file['type'] ?? 'application/octet-stream');

        if ($size < 1 || $size > 16 * 1024 * 1024) {
            $this->failSend('El archivo debe pesar entre 1 byte y 16 MB.', $conversationId, $ajax);
        }

        $detected = $this->detectMediaType($mime, $orig);
        if ($detected === null) {
            $this->failSend('Solo imagen, video o audio.', $conversationId, $ajax);
        }
        [$type, $mime] = $detected;

        $dir = public_path('uploads/omni');
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            $this->failSend('No se pudo crear carpeta de uploads.', $conversationId, $ajax);
        }

        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION) ?: 'bin');
        $safe = 'omni_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . preg_replace('/[^a-z0-9]/', '', $ext);
        $dest = $dir . DIRECTORY_SEPARATOR . $safe;
        if (!move_uploaded_file($tmp, $dest)) {
            $this->failSend('No se pudo guardar el archivo.', $conversationId, $ajax);
        }

        $publicUrl = rtrim(app_base_url(), '/') . '/uploads/omni/' . $safe;
        $to = (string) ($conv['external_contact'] ?? '');

        $sent = MetaCloud::sendMedia($to, $type, $dest, $mime, $caption !== '' ? $caption : null);
        if (!$sent['ok']) {
            $this->failSend('No se pudo enviar media: ' . $sent['message'], $conversationId, $ajax);
        }

        $body = $caption !== '' ? $caption : ('[' . $type . '] ' . $orig);
        $store = Omnichannel::storeOutbound(
            $conversationId,
            $body,
            $type,
            $publicUrl,
            $sent['external_id'] ?? null
        );
        if (!$store['ok']) {
            $this->failSend('Enviado, pero no se guardó local: ' . $store['message'], $conversationId, $ajax);
        }

        if ($ajax) {
            $this->json([
                'ok'      => true,
                'message' => ucfirst($type) . ' enviado.',
                'msg'     => [
                    'id'        => $store['id'] ?? null,
                    'from'      => 'agent',
                    'text'      => $body,
                    'type'      => $type,
                    'media_url' => $publicUrl,
                    'time'      => date('H:i'),
                ],
                'conversation' => Omnichannel::findConversation($conversationId),
            ]);
        }

        flash('success', ucfirst($type) . ' enviado.');
        redirect('omnicanalidad?chat=' . $conversationId);
    }

    private function failSend(string $message, int $conversationId, bool $ajax, int $status = 422): void
    {
        if ($ajax) {
            $this->json(['ok' => false, 'message' => $message], $status);
        }
        flash('error', $message);
        redirect($conversationId > 0 ? ('omnicanalidad?chat=' . $conversationId) : 'omnicanalidad');
    }

    private function wantsJson(): bool
    {
        $accept = (string) ($_SERVER['HTTP_ACCEPT'] ?? '');
        $xhr = (string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
        return str_contains($accept, 'application/json')
            || strcasecmp($xhr, 'XMLHttpRequest') === 0
            || (string) ($_POST['ajax'] ?? '') === '1';
    }

    /** @return array{0:string,1:string}|null */
    private function detectMediaType(string $mime, string $filename): ?array
    {
        $mime = strtolower($mime);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $map = [
            'jpg' => ['image', 'image/jpeg'], 'jpeg' => ['image', 'image/jpeg'],
            'png' => ['image', 'image/png'], 'webp' => ['image', 'image/webp'],
            'gif' => ['image', 'image/gif'], 'mp4' => ['video', 'video/mp4'],
            'webm' => ['video', 'video/webm'], '3gp' => ['video', 'video/3gpp'],
            'ogg' => ['audio', 'audio/ogg'], 'oga' => ['audio', 'audio/ogg'],
            'mp3' => ['audio', 'audio/mpeg'], 'm4a' => ['audio', 'audio/mp4'],
            'aac' => ['audio', 'audio/aac'], 'amr' => ['audio', 'audio/amr'],
        ];
        if (isset($map[$ext])) {
            return $map[$ext];
        }
        if (str_starts_with($mime, 'image/')) {
            return ['image', $mime];
        }
        if (str_starts_with($mime, 'video/')) {
            return ['video', $mime];
        }
        if (str_starts_with($mime, 'audio/')) {
            return ['audio', $mime];
        }
        return null;
    }
}

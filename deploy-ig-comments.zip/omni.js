(() => {
  const cfg = window.ARYA_OMNI;
  if (!cfg?.urls) return;

  const app = document.getElementById('omniApp');
  const convList = document.getElementById('omniConvList');
  const convCount = document.getElementById('omniConvCount');
  const chatEmpty = document.getElementById('omniChatEmpty');
  const chatActive = document.getElementById('omniChatActive');
  const chatBox = document.getElementById('chatMessages');
  const chatName = document.getElementById('omniChatName');
  const chatMeta = document.getElementById('omniChatMeta');
  const chatStatus = document.getElementById('omniChatStatus');
  const kindBadgeEl = document.getElementById('omniKindBadge');
  const postCard = document.getElementById('omniPostCard');
  const postMedia = document.getElementById('omniPostMedia');
  const postCaption = document.getElementById('omniPostCaption');
  const postLink = document.getElementById('omniPostLink');
  const convIdInput = document.getElementById('omniConvId');
  const composeForm = document.getElementById('chatCompose');
  const chatMedia = document.getElementById('chatMedia');
  const chatAttachBtn = document.getElementById('chatAttachBtn');
  const chatFileName = document.getElementById('chatFileName');
  const chatAiBtn = document.getElementById('chatAiBtn');
  const chatMessage = document.getElementById('chatMessage');
  const chatSendBtn = document.getElementById('chatSendBtn');

  let currentChannel = cfg.channel || 'all';
  let selectedId = Number(cfg.selectedId || 0);
  let sending = false;
  let convAbort = null;
  let msgAbort = null;
  let listReq = 0;
  let msgReq = 0;

  const esc = (s) => String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

  const channelIcon = (id) => {
    const icons = {
      whatsapp: '<svg class="ch-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="#25D366" d="M12.04 2C6.58 2 2.15 6.4 2.15 11.83c0 1.99.57 3.84 1.56 5.43L2 22l4.9-1.61a10 10 0 0 0 5.14 1.42h.01c5.46 0 9.89-4.4 9.89-9.83C21.94 6.4 17.5 2 12.04 2zm5.75 13.99c-.24.68-1.4 1.25-1.93 1.33-.49.07-1.12.1-1.81-.11-.42-.13-.95-.31-1.64-.6-2.89-1.25-4.77-4.16-4.92-4.35-.14-.19-1.18-1.57-1.18-3 0-1.42.74-2.12 1-2.41.26-.29.57-.36.76-.36h.55c.17 0 .4-.06.63.48.24.55.81 1.9.88 2.04.07.14.12.31.02.5-.1.19-.14.31-.28.48-.14.17-.29.37-.42.5-.14.14-.28.29-.12.57.16.28.71 1.17 1.52 1.9 1.05.93 1.93 1.22 2.21 1.36.28.14.44.12.6-.07.16-.19.69-.8.88-1.08.19-.28.37-.23.63-.14.26.1 1.64.77 1.92.91.28.14.47.21.54.33.07.12.07.68-.17 1.36z"/></svg>',
      messenger: '<svg class="ch-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="#0084FF" d="M12 2C6.36 2 2 6.13 2 11.7c0 2.91 1.19 5.44 3.14 7.17V22l2.87-1.58c.9.25 1.85.38 2.99.38 5.64 0 10-4.13 10-9.7S17.64 2 12 2zm1.01 13.08-2.55-2.72-4.98 2.72 5.47-5.81 2.61 2.72 4.92-2.72-5.47 5.81z"/></svg>',
      instagram: '<svg class="ch-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="#E4405F" d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2zm0 2A3.8 3.8 0 0 0 4 7.8v8.4A3.8 3.8 0 0 0 7.8 20h8.4a3.8 3.8 0 0 0 3.8-3.8V7.8A3.8 3.8 0 0 0 16.2 4H7.8zm9.65 1.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5zM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/></svg>',
      web: '<svg class="ch-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="#00D4E8" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm7.9 9h-3.17a15.4 15.4 0 0 0-1.3-5.3A8.03 8.03 0 0 1 19.9 11zM12 4c.9 0 2.3 1.8 3.05 5H8.95C9.7 5.8 11.1 4 12 4zM4.1 13h3.17c.2 1.9.7 3.7 1.3 5.3A8.03 8.03 0 0 1 4.1 13zm3.17-2H4.1a8.03 8.03 0 0 1 4.47-5.3A15.4 15.4 0 0 0 7.27 11zM12 20c-.9 0-2.3-1.8-3.05-5h6.1C14.3 18.2 12.9 20 12 20zm3.43-2.7c.6-1.6 1.1-3.4 1.3-5.3h3.17a8.03 8.03 0 0 1-4.47 5.3zM9.55 13c.2 1.7.6 3.3 1.2 4.6.4.8.8 1.4 1.25 1.4s.85-.6 1.25-1.4c.6-1.3 1-2.9 1.2-4.6H9.55zm0-2h4.9c-.2-1.7-.6-3.3-1.2-4.6C12.85 5.6 12.45 5 12 5s-.85.6-1.25 1.4c-.6 1.3-1 2.9-1.2 4.6z"/></svg>',
    };
    return icons[id] || icons.web;
  };

  const channelBadge = (channel) => {
    const labels = { whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram', web: 'Web' };
    const id = String(channel || 'web');
    const label = labels[id] || (id.charAt(0).toUpperCase() + id.slice(1));
    return `<span class="ch-badge ch-badge-${esc(id)}">${channelIcon(id)}<span>${esc(label)}</span></span>`;
  };

  const kindBadge = (kind) => {
    if (String(kind) !== 'comment') return '';
    return '<span class="badge badge-comment" title="Comentario en publicación">💬 Comentario</span>';
  };

  let kindFilter = 'all';
  let lastConvItems = [];

  const setBusy = (on) => {
    if (app) app.dataset.busy = on ? '1' : '0';
  };

  const nowTime = () => new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });

  const apiUrl = (base, params = {}) => {
    const u = new URL(base, window.location.href);
    Object.entries(params).forEach(([k, v]) => {
      if (v == null || v === '') u.searchParams.delete(k);
      else u.searchParams.set(k, String(v));
    });
    return u.toString();
  };

  const fetchJson = async (url, opts = {}, signal) => {
    const res = await fetch(url, {
      credentials: 'same-origin',
      ...opts,
      signal,
      headers: {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        ...(opts.headers || {}),
      },
    });
    const data = await res.json();
    if (!res.ok || data?.ok === false) {
      throw new Error(data?.message || ('HTTP ' + res.status));
    }
    return data;
  };

  const scrollChat = () => {
    if (chatBox) chatBox.scrollTop = chatBox.scrollHeight;
  };

  const renderMessage = (m) => {
    const type = m.type || 'text';
    const media = m.media_url || null;
    let mediaHtml = '';
    if (media && type === 'image') {
      mediaHtml = `<a href="${esc(media)}" target="_blank" rel="noopener" class="msg-media"><img src="${esc(media)}" alt="imagen" loading="lazy"></a>`;
    } else if (media && type === 'video') {
      mediaHtml = `<video class="msg-media" controls preload="metadata" src="${esc(media)}"></video>`;
    } else if (media && type === 'audio') {
      mediaHtml = `<audio class="msg-audio" controls preload="metadata" src="${esc(media)}"></audio>`;
    }
    const textHtml = m.text ? `<div class="msg-text">${esc(m.text)}</div>` : '';
    return `<div class="msg msg-${esc(m.from)}">${mediaHtml}${textHtml}<span class="msg-time">${esc(m.time || '')}</span></div>`;
  };

  const applyKindFilter = (items) => {
    if (kindFilter === 'comment') {
      return items.filter((c) => String(c.thread_kind) === 'comment');
    }
    if (kindFilter === 'message') {
      return items.filter((c) => String(c.thread_kind || 'message') !== 'comment');
    }
    return items;
  };

  const renderConversations = (items, activeId) => {
    if (!convList) return;
    lastConvItems = items || [];
    const filtered = applyKindFilter(lastConvItems);
    if (!filtered.length) {
      const emptyMsg = kindFilter === 'comment'
        ? 'Sin comentarios en este canal.'
        : (kindFilter === 'message' ? 'Sin chats en este canal.' : 'Sin conversaciones en este canal.');
      convList.innerHTML = `<div class="empty-state"><p>${emptyMsg}</p></div>`;
      if (convCount) convCount.textContent = '0';
      return;
    }
    convList.innerHTML = filtered.map((c) => `
      <button type="button" class="conv-item ${String(c.id) === String(activeId) ? 'active' : ''}"
        data-conv-id="${esc(c.id)}"
        data-client="${esc(c.client)}"
        data-phone="${esc(c.phone || '')}"
        data-channel="${esc(c.channel || '')}"
        data-status="${esc(c.status || 'open')}"
        data-preview="${esc(c.preview || '')}"
        data-thread-kind="${esc(c.thread_kind || 'message')}">
        <div class="conv-top">
          <span class="conv-name">${esc(c.client)}</span>
          <span class="conv-time">${esc(c.time)}</span>
        </div>
        <div class="conv-preview">${esc(c.preview)}</div>
        <div class="conv-meta">
          ${channelBadge(c.channel)}
          ${kindBadge(c.thread_kind)}
          ${Number(c.unread) > 0 ? `<span class="badge badge-gold">${esc(c.unread)}</span>` : ''}
        </div>
      </button>
    `).join('');
    if (convCount) convCount.textContent = String(filtered.length);
  };

  const updateChannelUnreads = (channels) => {
    (channels || []).forEach((ch) => {
      const el = document.querySelector(`[data-unread-for="${ch.id}"]`);
      if (!el) return;
      const n = Number(ch.unread || 0);
      if (n > 0) {
        el.hidden = false;
        el.textContent = String(n);
      } else {
        el.hidden = true;
      }
    });
  };

  const patchListPreview = (id, preview, time) => {
    const btn = convList?.querySelector(`.conv-item[data-conv-id="${id}"]`);
    if (!btn) return;
    const prev = btn.querySelector('.conv-preview');
    const t = btn.querySelector('.conv-time');
    if (prev) prev.textContent = preview;
    if (t) t.textContent = time;
    btn.dataset.preview = preview;
    // mover al tope
    if (convList.firstElementChild !== btn) {
      convList.prepend(btn);
    }
  };

  const showChatShell = (conv) => {
    if (!conv) {
      if (chatEmpty) chatEmpty.hidden = false;
      if (chatActive) chatActive.hidden = true;
      selectedId = 0;
      return;
    }
    selectedId = Number(conv.id);
    if (chatEmpty) chatEmpty.hidden = true;
    if (chatActive) chatActive.hidden = false;
    const isComment = String(conv.thread_kind || '') === 'comment';
    chatActive?.classList.toggle('is-comment', isComment);
    if (kindBadgeEl) kindBadgeEl.hidden = !isComment;
    if (chatName) chatName.textContent = conv.client || '';
    if (chatMeta) {
      const ch = String(conv.channel || '');
      const chLabel = ch ? ch.charAt(0).toUpperCase() + ch.slice(1) : '';
      const kind = isComment ? ' · Comentario' : '';
      chatMeta.textContent = `${conv.phone || ''} · ${chLabel}${kind}`;
    }
    if (chatMessage) {
      chatMessage.placeholder = isComment
        ? 'Escribe una respuesta al comentario…'
        : 'Escribe un mensaje…';
    }
    if (postCard) {
      postCard.hidden = !isComment;
      if (isComment && postMedia) {
        const mediaUrl = conv.post_media_url || '';
        const permalink = conv.post_permalink || mediaUrl || '#';
        if (mediaUrl) {
          postMedia.innerHTML = `<a href="${esc(permalink)}" target="_blank" rel="noopener"><img src="${esc(mediaUrl)}" alt="Publicación" loading="lazy"></a>`;
        } else {
          postMedia.innerHTML = '<div class="comment-post-placeholder">Publicación sin vista previa todavía</div>';
        }
        if (postCaption) {
          postCaption.textContent = conv.post_caption || 'Responde al comentario sobre esta publicación.';
        }
        if (postLink) {
          if (conv.post_permalink) {
            postLink.hidden = false;
            postLink.href = conv.post_permalink;
          } else {
            postLink.hidden = true;
          }
        }
      }
    }
    if (chatStatus) {
      const st = String(conv.status || 'open');
      chatStatus.textContent = st.charAt(0).toUpperCase() + st.slice(1);
    }
    if (convIdInput) convIdInput.value = String(conv.id);
    document.querySelectorAll('.conv-item').forEach((el) => {
      el.classList.toggle('active', String(el.dataset.convId) === String(conv.id));
    });
    const url = new URL(window.location.href);
    url.searchParams.set('chat', String(conv.id));
    if (currentChannel && currentChannel !== 'all') url.searchParams.set('canal', currentChannel);
    else url.searchParams.delete('canal');
    history.replaceState({ chat: conv.id, canal: currentChannel }, '', url.toString());
  };

  const showChat = (conv, messages) => {
    showChatShell(conv);
    if (!conv) return;
    if (chatBox) {
      chatBox.innerHTML = (messages || []).map(renderMessage).join('');
      scrollChat();
    }
  };

  const loadConversations = async (channel, keepSelected = true) => {
    if (convAbort) convAbort.abort();
    convAbort = new AbortController();
    const myReq = ++listReq;
    currentChannel = channel || 'all';
    setBusy(true);
    document.querySelectorAll('.channel-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.channel === currentChannel);
    });
    if (convList) {
      convList.innerHTML = '<div class="empty-state"><p>Cargando…</p></div>';
    }
    try {
      const data = await fetchJson(
        apiUrl(cfg.urls.conversations, { canal: currentChannel }),
        {},
        convAbort.signal
      );
      if (myReq !== listReq) return;
      updateChannelUnreads(data.channels);
      const items = data.conversations || [];
      let nextId = keepSelected ? selectedId : 0;
      if (!items.some((c) => String(c.id) === String(nextId))) {
        nextId = items[0]?.id || 0;
      }
      renderConversations(items, nextId);
      if (nextId) {
        const item = items.find((c) => String(c.id) === String(nextId));
        if (item) showChatShell(item);
        await loadMessages(nextId, { soft: true });
      } else {
        showChat(null, []);
      }
    } catch (e) {
      if (e.name === 'AbortError') return;
      console.error(e);
      if (convList) convList.innerHTML = '<div class="empty-state"><p>Error al cargar conversaciones.</p></div>';
    } finally {
      if (myReq === listReq) setBusy(false);
    }
  };

  const loadMessages = async (id, { soft = false } = {}) => {
    if (!id) return;
    if (msgAbort) msgAbort.abort();
    msgAbort = new AbortController();
    const myReq = ++msgReq;
    selectedId = Number(id);
    if (!soft) setBusy(true);

    // UI inmediata desde el botón de lista
    const btn = convList?.querySelector(`.conv-item[data-conv-id="${id}"]`);
    if (btn) {
      showChatShell({
        id,
        client: btn.dataset.client || btn.querySelector('.conv-name')?.textContent || '',
        phone: btn.dataset.phone || '',
        channel: btn.dataset.channel || '',
        status: btn.dataset.status || 'open',
        thread_kind: btn.dataset.threadKind || 'message',
      });
      // quitar solo unread, no el badge "Comentario"
      btn.querySelectorAll('.badge-gold').forEach((el) => {
        if (el.textContent && /^\d+$/.test(el.textContent.trim())) el.remove();
      });
    } else if (chatBox && !soft) {
      chatBox.innerHTML = '<div class="empty-state"><p>Cargando mensajes…</p></div>';
    }

    try {
      const endpoint = String(cfg.urls.messagesTpl || '').replace('__ID__', encodeURIComponent(id));
      const data = await fetchJson(endpoint, {}, msgAbort.signal);
      if (myReq !== msgReq) return;
      showChat(data.conversation, data.messages || []);
      if (data.channels) updateChannelUnreads(data.channels);
    } catch (e) {
      if (e.name === 'AbortError') return;
      console.error(e);
    } finally {
      if (myReq === msgReq && !soft) setBusy(false);
    }
  };

  document.getElementById('omniKindFilters')?.addEventListener('click', (e) => {
    const btn = e.target.closest('.kind-filter');
    if (!btn) return;
    kindFilter = btn.dataset.kind || 'all';
    document.querySelectorAll('.kind-filter').forEach((el) => {
      el.classList.toggle('active', el === btn);
    });
    renderConversations(lastConvItems, selectedId);
  });

  // Eventos canal / conversación (sin reload)
  document.getElementById('omniChannels')?.addEventListener('click', (e) => {
    const btn = e.target.closest('.channel-btn');
    if (!btn) return;
    e.preventDefault();
    const ch = btn.dataset.channel || 'all';
    if (ch === currentChannel) return;
    loadConversations(ch, false);
  });

  convList?.addEventListener('click', (e) => {
    const btn = e.target.closest('.conv-item');
    if (!btn) return;
    e.preventDefault();
    const id = btn.dataset.convId;
    if (!id) return;
    if (String(id) === String(selectedId) && chatActive && !chatActive.hidden) return;
    loadMessages(id);
  });

  chatAttachBtn?.addEventListener('click', () => chatMedia?.click());
  chatMedia?.addEventListener('change', () => {
    const file = chatMedia.files?.[0];
    if (!chatFileName) return;
    if (file) {
      chatFileName.hidden = false;
      chatFileName.textContent = file.name;
    } else {
      chatFileName.hidden = true;
      chatFileName.textContent = '';
    }
  });

  chatMessage?.addEventListener('input', () => {
    chatMessage.style.height = 'auto';
    chatMessage.style.height = Math.min(chatMessage.scrollHeight, 120) + 'px';
  });

  chatMessage?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      composeForm?.requestSubmit();
    }
  });

  composeForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (sending) return;
    const text = (chatMessage?.value || '').trim();
    const hasFile = !!(chatMedia?.files && chatMedia.files[0]);
    if (!text && !hasFile) return;
    if (!convIdInput?.value) return;

    sending = true;
    chatSendBtn?.classList.add('is-loading');
    chatSendBtn?.setAttribute('disabled', 'disabled');

    // FormData ANTES de limpiar el input (si no, el servidor recibe message vacío)
    const body = new FormData(composeForm);
    body.set('ajax', '1');
    body.set('message', text);
    body.set('conversation_id', String(convIdInput.value));

    const t = nowTime();
    let optimistic = false;
    if (text && !hasFile && chatBox) {
      chatBox.insertAdjacentHTML('beforeend', renderMessage({
        from: 'agent', text, type: 'text', time: t,
      }));
      scrollChat();
      patchListPreview(convIdInput.value, text, t);
      chatMessage.value = '';
      chatMessage.style.height = 'auto';
      optimistic = true;
    }

    try {
      const data = await fetchJson(cfg.urls.send, { method: 'POST', body });
      if (hasFile && data.msg && chatBox) {
        chatBox.insertAdjacentHTML('beforeend', renderMessage(data.msg));
        scrollChat();
        if (chatMedia) chatMedia.value = '';
        if (chatFileName) { chatFileName.hidden = true; chatFileName.textContent = ''; }
        if (chatMessage) { chatMessage.value = ''; chatMessage.style.height = 'auto'; }
        patchListPreview(convIdInput.value, data.msg.text || '[archivo]', data.msg.time || t);
      }
    } catch (err) {
      if (optimistic && chatMessage) {
        chatMessage.value = text;
        chatMessage.dispatchEvent(new Event('input'));
      }
      alert(err.message || 'No se pudo enviar');
      await loadMessages(convIdInput.value);
    } finally {
      sending = false;
      chatSendBtn?.classList.remove('is-loading');
      chatSendBtn?.removeAttribute('disabled');
    }
  });

  chatAiBtn?.addEventListener('click', async () => {
    const draft = (chatMessage?.value || '').trim();
    if (!draft) { chatMessage?.focus(); return; }
    chatAiBtn.classList.add('is-loading');
    chatAiBtn.textContent = 'IA…';
    try {
      const body = new FormData();
      body.append('_csrf', cfg.csrf || '');
      body.append('message', draft);
      body.append('conversation_id', convIdInput?.value || '');
      const data = await fetchJson(cfg.urls.improve, { method: 'POST', body });
      if (data.text && chatMessage) {
        chatMessage.value = data.text;
        chatMessage.dispatchEvent(new Event('input'));
      } else {
        alert(data.message || 'No se pudo mejorar');
      }
    } catch (err) {
      alert(err.message || 'Error al contactar OpenAI');
    } finally {
      chatAiBtn.classList.remove('is-loading');
      chatAiBtn.textContent = '✨ IA';
    }
  });

  // Seed lista SSR para filtros Todos/Chats/Comentarios
  convList?.querySelectorAll('.conv-item').forEach((btn) => {
    if (!btn.dataset.client) {
      btn.dataset.client = btn.querySelector('.conv-name')?.textContent?.trim() || '';
    }
    lastConvItems.push({
      id: btn.dataset.convId,
      client: btn.dataset.client || '',
      phone: btn.dataset.phone || '',
      channel: btn.dataset.channel || '',
      status: btn.dataset.status || 'open',
      preview: btn.dataset.preview || btn.querySelector('.conv-preview')?.textContent || '',
      time: btn.querySelector('.conv-time')?.textContent || '',
      unread: 0,
      thread_kind: btn.dataset.threadKind || 'message',
    });
  });

  scrollChat();
})();
